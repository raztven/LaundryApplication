import tkinter as tk
from tkinter import messagebox
import json
import os
from datetime import datetime

# Path file JSON
folder_path = "data_json"
json_path = os.path.join(folder_path, "daftar_transaksi.json")

if not os.path.exists(folder_path):
    os.makedirs(folder_path)

if not os.path.exists(json_path):
    with open(json_path, "w") as f:
        json.dump([], f)

# Daftar harga per kg
harga_per_kg = {
    "Cuci Kering": 5000,
    "Cuci Setrika": 7000,
    "Setrika Saja": 4000,
    "Express (Selesai 1 Hari)": 10000,
    "Karpet": 15000,
    "Bed Cover": 20000
}

def hitung_total():
    try:
        berat = float(entry_berat.get())
        jasa = jasa_var.get()

        if jasa in harga_per_kg:
            total = berat * harga_per_kg[jasa]
            label_total.config(text=f"Total: Rp {total:,.0f}")
            return total
        else:
            messagebox.showwarning("Peringatan", "Pilih jenis jasa laundry.")
            return 0
    except ValueError:
        messagebox.showerror("Error", "Berat harus berupa angka.")
        return 0

def simpan_data():
    nama = entry_nama.get()
    no_hp = entry_hp.get()
    alamat = entry_alamat.get()
    jasa = jasa_var.get()
    berat = entry_berat.get()
    kurir = kurir_var.get()
    bayar = entry_bayar.get()

    if not nama or not no_hp or not alamat or not berat or jasa == "Pilih Jasa" or kurir == "Pilih Kurir" or not bayar:
        messagebox.showwarning("Peringatan", "Semua data harus diisi.")
        return

    try:
        berat = float(berat)
        bayar = float(bayar)
    except ValueError:
        messagebox.showerror("Error", "Berat dan pembayaran harus angka.")
        return

    total = hitung_total()

    if bayar < total:
        messagebox.showerror("Gagal", "Uang bayar kurang dari total!")
        return

    kembalian = bayar - total

    data_baru = {
        "nama": nama,
        "no_hp": no_hp,
        "alamat": alamat,
        "jasa": jasa,
        "berat": berat,
        "kurir": kurir,
        "total": total,
        "bayar": bayar,
        "kembalian": kembalian,
        "waktu": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    with open(json_path, "r") as f:
        daftar_transaksi = json.load(f)

    daftar_transaksi.append(data_baru)

    with open(json_path, "w") as f:
        json.dump(daftar_transaksi, f, indent=4)

    # Tampilkan struk
    messagebox.showinfo("Struk Pembayaran", f"""
🧺 STRUK PEMBAYARAN LAUNDRY
-----------------------------
Nama      : {nama}
No HP     : {no_hp}
Alamat    : {alamat}
Jasa      : {jasa}
Berat     : {berat} kg
Total     : Rp {total:,.0f}
Dibayar   : Rp {bayar:,.0f}
Kembalian : Rp {kembalian:,.0f}
Waktu     : {data_baru["waktu"]}
-----------------------------
Terima kasih telah menggunakan layanan kami!
""")

    # Reset form
    entry_nama.delete(0, tk.END)
    entry_hp.delete(0, tk.END)
    entry_alamat.delete(0, tk.END)
    entry_berat.delete(0, tk.END)
    entry_bayar.delete(0, tk.END)
    jasa_var.set("Pilih Jasa")
    kurir_var.set("Pilih Kurir")
    label_total.config(text="Total: Rp 0")

    tampilkan_data()

def tampilkan_data():
    try:
        with open(json_path, "r") as f:
            daftar = json.load(f)

        text_output.config(state="normal")
        text_output.delete(1.0, tk.END)

        if not daftar:
            text_output.insert(tk.END, "Belum ada data transaksi.\n")
        else:
            for i, data in enumerate(daftar, start=1):
                baris = (
                    f"{i}. {data['nama']} | {data['jasa']} | "
                    f"{data['berat']} kg | Rp {data['total']:,.0f}\n"
                )
                text_output.insert(tk.END, baris)

        text_output.config(state="disabled")
    except Exception as e:
        text_output.config(state="normal")
        text_output.delete(1.0, tk.END)
        text_output.insert(tk.END, f"⚠️ Gagal menampilkan data: {e}")
        text_output.config(state="disabled")

# GUI
root = tk.Tk()
root.title("🧺 Aplikasi Laundry")
root.configure(bg="#f9f9f9")


font_label = ("Segoe UI", 10)
font_entry = ("Segoe UI", 10)
font_button = ("Segoe UI", 10, "bold")

def add_label_entry(text, row):
    tk.Label(root, text=text, font=font_label, bg="#f9f9f9").grid(row=row, column=0, sticky="w", padx=10, pady=5)
    entry = tk.Entry(root, font=font_entry, width=30)
    entry.grid(row=row, column=1, padx=10, pady=5)
    return entry

entry_nama = add_label_entry("Nama Pelanggan", 0)
entry_hp = add_label_entry("No HP", 1)
entry_alamat = add_label_entry("Alamat", 2)

# Jasa
tk.Label(root, text="Jenis Jasa", font=font_label, bg="#f9f9f9").grid(row=3, column=0, sticky="w", padx=10, pady=5)
jasa_var = tk.StringVar(value="Pilih Jasa")
jasa_option = tk.OptionMenu(root, jasa_var, *harga_per_kg.keys())
jasa_option.config(font=font_entry, width=28)
jasa_option.grid(row=3, column=1, padx=10, pady=5)



# Kurir
tk.Label(root, text="Layanan Kurir", font=font_label, bg="#f9f9f9").grid(row=4, column=0, sticky="w", padx=10, pady=5)
kurir_var = tk.StringVar(value="Pilih Kurir")
kurir_option = tk.OptionMenu(root, kurir_var, "Antar", "Jemput", "Antar-Jemput", "Tidak Perlu")
kurir_option.config(font=font_entry, width=28)
kurir_option.grid(row=4, column=1, padx=10, pady=5)

entry_berat = add_label_entry("Berat (kg)", 5)

btn_hitung = tk.Button(root, text="Hitung Total", bg="#007ACC", fg="white", font=font_button, command=hitung_total)
btn_hitung.grid(row=6, column=0, columnspan=2, pady=5)

label_total = tk.Label(root, text="Total: Rp 0", font=("Segoe UI", 11, "bold"), bg="#f9f9f9", fg="#333")
label_total.grid(row=7, column=0, columnspan=2, pady=5)

entry_bayar = add_label_entry("Uang Bayar", 8)

btn_simpan = tk.Button(root, text="Simpan Transaksi", bg="#28a745", fg="white", font=font_button, command=simpan_data)
btn_simpan.grid(row=9, column=0, columnspan=2, pady=10)

# Riwayat transaksi
tk.Label(root, text="🗂️ Riwayat Transaksi", font=("Segoe UI", 10, "bold"), bg="#f9f9f9", fg="#333").grid(row=10, column=0, columnspan=2, pady=(10, 0))
text_output = tk.Text(root, height=10, width=60, font=("Consolas", 9), state="disabled", bg="#fff", relief="solid", bd=1)
text_output.grid(row=11, column=0, columnspan=2, padx=10, pady=5)

tampilkan_data()
root.mainloop()
